"use strict";
exports.__esModule = true;
var ResponseModel = /** @class */ (function () {
    function ResponseModel() {
        this.data = [];
        this.code = -1;
        this.page = -1;
        this.pageSize = -1;
        this.rows = -1;
    }
    return ResponseModel;
}());
exports.ResponseModel = ResponseModel;
